package com.mercury.pas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MercuryPasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercuryPasApplication.class, args);
	}
}
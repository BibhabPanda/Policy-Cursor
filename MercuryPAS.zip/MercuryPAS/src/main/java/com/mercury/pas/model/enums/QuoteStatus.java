package com.mercury.pas.model.enums;



public enum QuoteStatus {

    SAVED, GENERATED, CONVERTED

}




package com.mercury.pas.model.enums;



public enum ClaimStatus {

    NEW, UNDER_REVIEW, APPROVED, REJECTED

}




package com.mercury.pas.model.enums;



public enum Role {

    ADMIN, AGENT, CUSTOMER

}




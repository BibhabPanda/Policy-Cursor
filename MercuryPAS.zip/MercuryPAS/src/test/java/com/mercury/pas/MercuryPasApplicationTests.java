package com.mercury.pas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercuryPasApplicationTests {

	@Test
	void contextLoads() {
	}

}
